<?php   
  $lang['adminpanellogin'] = 'Admin Panel Login';
  $lang['username']        = 'Username';
  $lang['password']        = 'Password';
  $lang['dashboard']       = 'Dashboard';
  $lang['home']            = 'Home';
  $lang['library_crm']     = 'Library CRM';
  $lang['book']            = 'Book';
  $lang['book_list']       = 'Book List';
  $lang['user']            = 'User';
  $lang['user_list']       = 'User List';
  $lang['setting']         = 'Setting';
  $lang['language']        = 'Language';
  $lang['search']          = 'Search';


?>