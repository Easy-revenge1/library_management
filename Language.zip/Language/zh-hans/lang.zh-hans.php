<?php   
  $lang['adminpanellogin'] = '管理员面板登录';
  $lang['username']        = '用户名';
  $lang['password']        = '密码';
  $lang['dashboard']       = '仪表板';
  $lang['home']            = '主页';
  $lang['library_crm']     = '图书馆 CRM';
  // $lang['dashboard']       = 'Dashboard';

?>