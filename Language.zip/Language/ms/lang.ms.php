<?php   
  $lang['adminpanellogin'] = 'Log Masuk Panel Admin';
  $lang['username']        = 'Nama Pengguna';
  $lang['password']        = 'Kata Laluan';
  $lang['dashboard']       = 'Papan Pemuka';
  $lang['home']            = 'Laman Utama';
  $lang['library_crm']     = 'CRM Perpustakaan';
  $lang['dashboard']       = 'Dashboard';

?>