<?php   
  $lang['adminpanellogin'] = '管理員面板登入';
  $lang['username']        = '用户名';
  $lang['password']        = '密碼';
  $lang['dashboard']        = '儀表板';
  $lang['home']             = '首頁';
  $lang['dashboard']       = '圖書館 CRM';
  $lang['dashboard']       = 'Dashboard';

?>